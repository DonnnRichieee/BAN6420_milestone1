# Policy Management System

This is a Python program for managing policyholders, products, and payments within an insurance company.

## Getting Started

Follow these instructions to get a copy of the project up and running on your local machine.

### Prerequisites

- Python 3.x
- Jupyter Notebook (optional)

### Usage

The project consists of several Python files:

- `policyholders_class.ipynb`: Contains the `Policyholder` class for managing policyholders.
- `products_class.ipynb`: Contains the `Product` class for managing products.
- `payments_class.ipynb`: Contains the `Payment` class for managing payments.
- `main.ipynb`: Contains the main script to demonstrate the functionality of the classes.

### Instructions

1. Create instances of `Policyholder` class using the `name`, `policy_number`, and `status` (optional) parameters.
2. Create instances of `Product` class using the `name` and `price` parameters.
3. Create instances of `Payment` class using a `policyholder` object, the name of the product, and the payment amount.
4. Use the methods provided by each class (`register`, `suspend`, `reactivate` for `Policyholder`; `create_product`, `update_product`, `remove_product`, `suspend_product`, `display_products` for `Product`; `process_payment`, `send_reminder`, `apply_penalty` for `Payment`) to perform various tasks.

### Example

```python
from policyholder import Policyholder
from product import Product
from payment import Payment

# Creating instances of Policyholder and ProductManagement classes
policyholder1 = Policyholder("Wale Johnson", "PLA001")
policyholder2 = Policyholder("Adeitan Richard", "PLA002")

# Creating payments
payment1 = Payment(policyholder1, "Health Insurance", 100)
payment2 = Payment(policyholder2, "Car Insurance", 150)

# Create an instance of the Product class
product_manager = Product()

# Create products
product_manager.create_product("Health Insurance", 100)
product_manager.create_product("Car Insurance", 150)

print("\n")

# Update a product
product_manager.update_product("Health Insurance", 120)

print("\n")
# Display products
product_manager.display_products()


# Displaying policyholder account details
print("Policyholder 1:")
policyholder1.display_details()

print("\nPolicyholder 2:")
policyholder2.display_details()

print("\n")

# Processing payments
payment1.process_payment()
payment2.process_payment()
